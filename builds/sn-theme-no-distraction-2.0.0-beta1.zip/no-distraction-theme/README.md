# No Distraction Theme

Narrows your focus to the current note you're working on.

![Preview](./preview.png)